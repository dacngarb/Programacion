/*
 * Descripción: Ejercicio 1
 * Autor: David Cantero García
 * Echa: 24/09/2025
 */

package ejercicio1;

public class Ejercicio1 
{
	public static void main (String args [])
	{
		//Imprimir para que salga en pantalla la siguiente frase
		System.out.println ("Este es mi primer programa Java");
		
	}

}
