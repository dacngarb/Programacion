/*
 * Descripción: Ejercicio 2
 * Autor: David Cantero García
 * Echa: 24/09/2025
 */


package ejercicio2;

public class Ejercicio2 {

	public static void main (String args [])
	{
		//Imprimir para que salga en pantalla los siguientes datos
		System.out.println ("Desarrollo de Aplicaciones WEB/Multiplataforma");
		System.out.println ("1DAW /DAM");
		System.out.println ("Módulos:"); //Con "println" cambia de línea
		System.out.println ("Pro");
		System.out.println ("SIS");
		
	}


}
