/*
 * Descripción: Ejercicio 3 resuelto
 * Autor: David Cantero García
 * Eecha: 27/09/2025
 */

package ejercicio3Resuelto;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		double metros;
		double pulgada, pie, pulgadas, yarda;
		
		pulgada = 1;
		pie = 2.54;
		pulgadas, yarda = 
		
	}

}
