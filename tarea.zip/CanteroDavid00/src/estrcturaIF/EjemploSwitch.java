/*
 * Descripción: Ejercicio ejemplo Switch
 * Autor: David Cantero García
 * Eecha: 08/10/2025
 */

package estrcturaIF;

import java.util.Scanner;

public class EjemploSwitch {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.print("Dime tu nota academica: ");
		int notaAcademica;
		notaAcademica = teclado.nextInt();
		
		String notaTexto;
		
		//Declaro que segungun la nota que tengo le pondra una de estas notas
		switch (notaAcademica) {
			case 1,2,3,4: {
				notaTexto = "Insuficiente";
				break;
			}
			case 5: { 
				notaTexto = "Suficiente";
				break;
			}
			case 6: {
				notaTexto = "Bien";
				break;
			}
			case 7,8: {	
				notaTexto = "Notable";
				break;
			}
			case 9,10: {	
				notaTexto = "Sobresaliente";
				break;
			}
			default:{
				notaTexto = "no valido";
			}
		}
		
		if (notaTexto.equals("no valido")) {
			System.out.println("La nota no es valida");
		}else {
			System.out.println("Nota: " + notaTexto);
		}
		
	}

}
