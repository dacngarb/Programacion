/*
 * Descripción: Mostrar en consola un texto
 * Autor: YO
 * Echa: 19/09/2025
 */
package miNombre;

public class MiNombre {

	public static void main(String[] args) {
		System.out.print("David Cantero García");

	}

}
