/*
 * Descripción: Como funciona el operador condicional
 * Autor: David Cantero
 * Eecha: 26/09/2025
 */

package operadores;

import java.util.Scanner;

public class EjemploOPCondicional {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		//mostrar la longitd de caracteres de mi nombre
		String nombre;
		System.out.println("Dime tu nombre:");
		nombre = teclado.nextLine();
		int longitud = nombre.length();
		System.out.println("Número de caracteres: " + longitud);
		
		//Mostrar el nombre en mayusculas
		String mayusculas;
		System.out.println("Nombre en minusculas: ");
		mayusculas = teclado.nextLine();
		System.out.println("El nombre en mayusculas es: " + mayusculas.toUpperCase());
		
		//Mostrar el nombre en minusculas
		String minusculas;
		System.out.println("Nombre en mayusculas: ");
		minusculas = teclado.nextLine();
		System.out.println("El nombre en minusculas es: " + minusculas.toLowerCase());
		
		//comparacion de cadenas 
		boolean esDavid;
		nombre = nombre.toLowerCase();
		esDavid = nombre.equals("david");//si es el nombre que marca saldra true sino false
		System.out.println(esDavid);
		
		/*	
		 //mostrar si al poner un numero te dice que eres mayor o menor de edad	
		int edad;
		System.out.println("Dime tu edad:");
		edad = teclado.nextInt();
	
		String mayorEdad;
		mayorEdad = (edad > 18) ? "Eres mayor de edad": "Eres menor de edad";
		System.out.println(mayorEdad);
*/
	}

}
