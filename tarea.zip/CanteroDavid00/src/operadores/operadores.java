package operadores;

import java.util.Scanner;

public class operadores {

	public static void main(String[] args) {
		
		Scanner operadores = new Scanner(System.in);


		int dato1, dato3;
		double dato2;
		
		
		dato1 = 5;
		dato2 = 4;
		dato3 = 4;
		
		double suma; 
		suma = dato1+dato2;
		System.out.println("La suma es: " + suma);
		
		double resta;
		resta = dato1-dato2;
		System.out.println("La resta es: " + resta);
		
		double multiplicacion;
		multiplicacion = dato1*dato2;
		System.out.println("La multiplicación es: " + multiplicacion);
		
		double division; 
		division = dato1/dato2;
		System.out.println("La división es: " + division);
		
		int resto; 
		resto = dato1 % dato3;
		System.out.println("El resto es: " + resto);
		
		int dato1mas, dato1menos;
		dato1mas = dato1++; // dato1mas = dato1 + 1
		dato1menos = dato1--; // dato1menos = dato1 - 1
		
		System.out.println("Incremental posterior " + ++dato1);
		
		System.out.println("Incremental posterior " + ++dato1);
		System.out.println(dato1);
		dato1 = dato1 +1;

		boolean distinto = dato1 != dato2;
		System.out.println(distinto);

	}

}