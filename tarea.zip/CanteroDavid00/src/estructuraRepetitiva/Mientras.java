/*
 * Descripción: EJEMPLO ESTRUCTURA WHILE
 * Autor: David Cantero García
 * Eecha: 09/10/2025
 */

package estructuraRepetitiva;

import java.util.Scanner;

public class Mientras {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int num, suma, contador;
		System.out.println("Dame un numero: ");
		num = teclado.nextInt();
		contador = 1;
		suma = num;
		
		while (num != 0 && contador != 8) { //si el usuario pone un cero termina de sumar, y si pone mas de 8 numeros tambien para
			System.out.println("Dame un numero: ");
			num = teclado.nextInt();
			contador = contador + 1; //contador++
			suma = suma + num; //acumulador, acumula en sum lo que de num y lo suma
		}
		System.out.println("La suma es: " + suma);
		
	}

}
