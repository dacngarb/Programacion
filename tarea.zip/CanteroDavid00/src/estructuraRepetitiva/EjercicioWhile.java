/*
 * Descripción: EJErcicio ESTRUCTURA WHILE
 * Autor: David Cantero García
 * Eecha: 09/10/2025
 */

package estructuraRepetitiva;

import java.util.Scanner;

public class EjercicioWhile {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int inicio, fin, contador;
		
		System.out.print("Dame un número de inicio: ");
		inicio = teclado.nextInt();
		
		System.out.print("Dame un número de fin: ");
		fin = teclado.nextInt();
		
		contador = inicio;
		
		while (contador >= fin) {
			System.out.print(" " + contador);
			contador =  contador - 1;
			
		}
		
	}

}
