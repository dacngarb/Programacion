

package estructuraRepetitiva;

import java.util.Scanner;

public class Multiplo3 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int inicio, fin, contador;
		
		System.out.print("Dame un número de inicio: ");
		inicio = teclado.nextInt();
		
		System.out.print("Dame un número de fin: ");
		fin = teclado.nextInt();
		
		if (inicio <= fin) { //secuencia creciente
				System.out.println("Multiplo de 3 desde " + inicio + " hasta " + fin );
				contador = inicio;
				
			do {
				if (contador % 3 == 0) { //compruebo que es múltiplo de 3
					System.out.print(" " + contador);
				}
				contador = contador  + 1;
			} while (contador <= fin);
			
		} else {   //secuencia decreciente
				System.out.println("Multiplo de 3 desde " + inicio + " hasta " + fin );
				contador = inicio;
				
			do { 
				if (contador % 3 == 0) { //compruebo que es múltiplo de 3
					System.out.print(" " + contador);
				}
				contador = contador  - 1;
			} while (contador >= fin);
			
		}
		
	
		
	}

}
