/*
 * Descripción: Ejercicio 3
 * Autor: David Cantero García
 * Eecha: 01/10/2025
 */


package ejercicio3;

public class Ejercicio3 {

	public static void main(String[] args) {
		

	}

}
