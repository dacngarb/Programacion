/*
 * Descripción: Ejercicio 4
 * Autor: David Cantero García
 * Echa: 25/09/2025
 */


package ejercicio4;

public class Ejercicio4 {

	public static void main(String[] args) {
		byte a;
		a = 111;
		System.out.println("El valor de la variable de tipo byte es: " + a);
		
		short b; 
		b = 24704;
		System.out.println("El valor de la variable de tipo short es: " + b);
		
		int c; 
		c = 647372676;
		System.out.println("El valor de la variable de tipo entero es: " + c);
		
		char d;
		d = 'D';
		System.out.println("El valor de la variable de tipo caráter es: " + d);
		
		double e;
		e = 0.74;
		System.out.println("El valor de la variable de tipo número decimal es: " + e);
		
		float f;
		f = 22.34f; //se añade la letra f para que sepa que la variable es de tipo float
		System.out.println("El valor de la variable de tipo número flotante es: " + f);
		
		String g;
		g = "Programación";
		System.out.println("El valor de la variable de tipo cadena de caracteres es: " + g);
		
	}

}
